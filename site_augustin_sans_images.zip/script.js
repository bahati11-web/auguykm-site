document.addEventListener("DOMContentLoaded", () => {
  console.log("%cBienvenue sur le site d'Augustin Kamengele (version sans image) !", "color: #0077cc; font-size: 16px; font-weight: bold;");
});
